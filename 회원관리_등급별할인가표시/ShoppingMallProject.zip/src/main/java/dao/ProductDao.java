package dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import vo.ProductVo;

public class ProductDao {

	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public int insert(ProductVo vo) {
		
		int res = sqlSession.insert("product.product_insert", vo);
		
		return res;
	}

	public List<ProductVo> selectAllList(Map map) {
		// TODO Auto-generated method stub
		return sqlSession.selectList("product.product_list", map);
	}
	
	public List<ProductVo> selectCondList(Map map) {
		// TODO Auto-generated method stub
		return sqlSession.selectList("product.product_condition_list", map);
	}


	public ProductVo selectOne(Integer p_idx) {
		// TODO Auto-generated method stub
		ProductVo vo = sqlSession.selectOne("product.product_one", p_idx);
		return vo;
	}

	public int selectRowTotal(Map map) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("product.product_row_total", map);
	}

	
}
