package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.GradeVo;

public class GradeDao {

	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public int insert(String m_id) {
		
		return sqlSession.insert("grade.grade_insert", m_id);
	}

	public List<GradeVo> selectList() {
		// TODO Auto-generated method stub
		return sqlSession.selectList("grade.grade_list");
	}

	public GradeVo selectOne(String m_id) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("grade.grade_one", m_id);
	}

	public int update(GradeVo grade_vo) {
		// TODO Auto-generated method stub
		return sqlSession.update("grade.grade_update", grade_vo);
	}

	public int updateGrade(GradeVo g_vo) {
		// TODO Auto-generated method stub
		return sqlSession.update("grade.g_grade_update", g_vo);
	}
}
