package vo;

public class ProductVo {

	int p_idx;
	String p_name;
	String p_bKind;
	String p_sKind;
	int p_price;
	String p_regdate;
	String p_filename;
	String p_explain;
	
	public ProductVo() {
		// TODO Auto-generated constructor stub
	}
	
	public ProductVo(String p_name, String p_bKind, String p_sKind, int p_price, String p_explain) {
		super();
		this.p_name = p_name;
		this.p_bKind = p_bKind;
		this.p_sKind = p_sKind;
		this.p_price = p_price;
		this.p_explain = p_explain;
	}
	
	public int getP_idx() {
		return p_idx;
	}
	public void setP_idx(int p_idx) {
		this.p_idx = p_idx;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_bKind() {
		return p_bKind;
	}
	public void setP_bKind(String p_bKind) {
		this.p_bKind = p_bKind;
	}
	public String getP_sKind() {
		return p_sKind;
	}
	public void setP_sKind(String p_sKind) {
		this.p_sKind = p_sKind;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	public String getP_regdate() {
		return p_regdate;
	}
	public void setP_regdate(String p_regdate) {
		this.p_regdate = p_regdate;
	}
	public String getP_filename() {
		return p_filename;
	}
	public void setP_filename(String p_filename) {
		this.p_filename = p_filename;
	}
	public String getP_explain() {
		return p_explain;
	}
	public void setP_explain(String p_explain) {
		this.p_explain = p_explain;
	}
	
	
	
}
