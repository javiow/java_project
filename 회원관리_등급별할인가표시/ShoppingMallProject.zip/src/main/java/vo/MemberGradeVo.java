package vo;

import java.util.List;

public class MemberGradeVo {
	
	String m_id; 
	String m_name; 
	String m_pwd; 
	String m_birth; 
	String m_email;
	String m_tel; 
	int m_age; 
	String m_gender; 
	String m_addr; 
	String m_zipcode;
	String m_position; 
	String g_grade; 
	int g_count; 
	int g_price; 
	String g_recdate; 
	String g_joindate;
	 	
	public MemberGradeVo() {
		// TODO Auto-generated constructor stub
	}

	public String getM_id() {
		return m_id;
	}

	public void setM_id(String m_id) {
		this.m_id = m_id;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getM_pwd() {
		return m_pwd;
	}

	public void setM_pwd(String m_pwd) {
		this.m_pwd = m_pwd;
	}

	public String getM_birth() {
		return m_birth;
	}

	public void setM_birth(String m_birth) {
		this.m_birth = m_birth;
	}

	public String getM_email() {
		return m_email;
	}

	public void setM_email(String m_email) {
		this.m_email = m_email;
	}

	public String getM_tel() {
		return m_tel;
	}

	public void setM_tel(String m_tel) {
		this.m_tel = m_tel;
	}

	public int getM_age() {
		return m_age;
	}

	public void setM_age(int m_age) {
		this.m_age = m_age;
	}

	public String getM_gender() {
		return m_gender;
	}

	public void setM_gender(String m_gender) {
		this.m_gender = m_gender;
	}

	public String getM_addr() {
		return m_addr;
	}

	public void setM_addr(String m_addr) {
		this.m_addr = m_addr;
	}

	public String getM_zipcode() {
		return m_zipcode;
	}

	public void setM_zipcode(String m_zipcode) {
		this.m_zipcode = m_zipcode;
	}

	public String getM_position() {
		return m_position;
	}

	public void setM_position(String m_position) {
		this.m_position = m_position;
	}

	public String getG_grade() {
		return g_grade;
	}

	public void setG_grade(String g_grade) {
		this.g_grade = g_grade;
	}

	public int getG_count() {
		return g_count;
	}

	public void setG_count(int g_count) {
		this.g_count = g_count;
	}

	public int getG_price() {
		return g_price;
	}

	public void setG_price(int g_price) {
		this.g_price = g_price;
	}

	public String getG_recdate() {
		return g_recdate;
	}

	public void setG_recdate(String g_recdate) {
		this.g_recdate = g_recdate;
	}

	public String getG_joindate() {
		return g_joindate;
	}

	public void setG_joindate(String g_joindate) {
		this.g_joindate = g_joindate;
	}
	
		
	
	
}
