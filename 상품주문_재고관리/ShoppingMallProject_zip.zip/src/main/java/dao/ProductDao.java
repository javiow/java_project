package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.MemberVo;
import vo.ProductVo;

public class ProductDao {

	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public int insert(ProductVo vo) {
		
		int res = sqlSession.insert("product.product_insert", vo);
		
		return res;
	}

	public List<ProductVo> selectList() {
		// TODO Auto-generated method stub
		return sqlSession.selectList("product.product_list");
	}
	
	public List<ProductVo> selectList(String search_text) {
		// TODO Auto-generated method stub
		return sqlSession.selectList("product.product_condition_list", search_text);
	}

	public List<ProductVo> selectListKind(String p_sKind) {
		// TODO Auto-generated method stub
		return sqlSession.selectList("product.product_kind_list", p_sKind);
	}

	public ProductVo selectOne(Integer p_idx) {
		// TODO Auto-generated method stub
		ProductVo vo = sqlSession.selectOne("product.product_one", p_idx);
		return vo;
	}

	
}
