package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.InStockVo;

public class InStockDao {

	
	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public int insert(InStockVo vo) {
		// TODO Auto-generated method stub
		return sqlSession.insert("instock.instock_insert", vo);
	}

	public List<InStockVo> selectList() {
		// TODO Auto-generated method stub
		return sqlSession.selectList("instock.instock_list");
	}
	
	
}
