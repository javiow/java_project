package dao;

import org.apache.ibatis.session.SqlSession;

import vo.MemberVo;

public class MemberDao {

	SqlSession sqlSession;

	public SqlSession getSqlSession() {
		return sqlSession;
	}

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public int insert(MemberVo vo) {
		
		int res = sqlSession.insert("member.member_insert", vo);
		
		return res;
	}

	public MemberVo selectOne(String m_id) {
		// TODO Auto-generated method stub
		
		MemberVo vo = sqlSession.selectOne("member.member_one", m_id);
		
		return vo;
	}
	
}
